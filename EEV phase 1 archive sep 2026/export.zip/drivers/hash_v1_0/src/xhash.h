// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHASH_H
#define XHASH_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhash_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XHash_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XHash;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHash_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHash_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHash_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHash_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XHash_Initialize(XHash *InstancePtr, UINTPTR BaseAddress);
XHash_Config* XHash_LookupConfig(UINTPTR BaseAddress);
#else
int XHash_Initialize(XHash *InstancePtr, u16 DeviceId);
XHash_Config* XHash_LookupConfig(u16 DeviceId);
#endif
int XHash_CfgInitialize(XHash *InstancePtr, XHash_Config *ConfigPtr);
#else
int XHash_Initialize(XHash *InstancePtr, const char* InstanceName);
int XHash_Release(XHash *InstancePtr);
#endif

void XHash_Start(XHash *InstancePtr);
u32 XHash_IsDone(XHash *InstancePtr);
u32 XHash_IsIdle(XHash *InstancePtr);
u32 XHash_IsReady(XHash *InstancePtr);
void XHash_EnableAutoRestart(XHash *InstancePtr);
void XHash_DisableAutoRestart(XHash *InstancePtr);
u32 XHash_Get_return(XHash *InstancePtr);

void XHash_Set_text_length(XHash *InstancePtr, u32 Data);
u32 XHash_Get_text_length(XHash *InstancePtr);
void XHash_Set_text_input(XHash *InstancePtr, u64 Data);
u64 XHash_Get_text_input(XHash *InstancePtr);
u32 XHash_Get_result_BaseAddress(XHash *InstancePtr);
u32 XHash_Get_result_HighAddress(XHash *InstancePtr);
u32 XHash_Get_result_TotalBytes(XHash *InstancePtr);
u32 XHash_Get_result_BitWidth(XHash *InstancePtr);
u32 XHash_Get_result_Depth(XHash *InstancePtr);
u32 XHash_Write_result_Words(XHash *InstancePtr, int offset, word_type *data, int length);
u32 XHash_Read_result_Words(XHash *InstancePtr, int offset, word_type *data, int length);
u32 XHash_Write_result_Bytes(XHash *InstancePtr, int offset, char *data, int length);
u32 XHash_Read_result_Bytes(XHash *InstancePtr, int offset, char *data, int length);

void XHash_InterruptGlobalEnable(XHash *InstancePtr);
void XHash_InterruptGlobalDisable(XHash *InstancePtr);
void XHash_InterruptEnable(XHash *InstancePtr, u32 Mask);
void XHash_InterruptDisable(XHash *InstancePtr, u32 Mask);
void XHash_InterruptClear(XHash *InstancePtr, u32 Mask);
u32 XHash_InterruptGetEnabled(XHash *InstancePtr);
u32 XHash_InterruptGetStatus(XHash *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
