// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xhash.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHash_CfgInitialize(XHash *InstancePtr, XHash_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHash_Start(XHash *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL) & 0x80;
    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHash_IsDone(XHash *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHash_IsIdle(XHash *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHash_IsReady(XHash *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHash_EnableAutoRestart(XHash *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XHash_DisableAutoRestart(XHash *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XHash_Get_return(XHash *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XHash_Set_text_length(XHash *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_TEXT_LENGTH_DATA, Data);
}

u32 XHash_Get_text_length(XHash *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_TEXT_LENGTH_DATA);
    return Data;
}

void XHash_Set_text_input(XHash *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_TEXT_INPUT_DATA, (u32)(Data));
    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_TEXT_INPUT_DATA + 4, (u32)(Data >> 32));
}

u64 XHash_Get_text_input(XHash *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_TEXT_INPUT_DATA);
    Data += (u64)XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_TEXT_INPUT_DATA + 4) << 32;
    return Data;
}

u32 XHash_Get_result_BaseAddress(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XHASH_CONTROL_ADDR_RESULT_BASE);
}

u32 XHash_Get_result_HighAddress(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XHASH_CONTROL_ADDR_RESULT_HIGH);
}

u32 XHash_Get_result_TotalBytes(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XHASH_CONTROL_ADDR_RESULT_HIGH - XHASH_CONTROL_ADDR_RESULT_BASE + 1);
}

u32 XHash_Get_result_BitWidth(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHASH_CONTROL_WIDTH_RESULT;
}

u32 XHash_Get_result_Depth(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHASH_CONTROL_DEPTH_RESULT;
}

u32 XHash_Write_result_Words(XHash *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XHASH_CONTROL_ADDR_RESULT_HIGH - XHASH_CONTROL_ADDR_RESULT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XHASH_CONTROL_ADDR_RESULT_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XHash_Read_result_Words(XHash *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XHASH_CONTROL_ADDR_RESULT_HIGH - XHASH_CONTROL_ADDR_RESULT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XHASH_CONTROL_ADDR_RESULT_BASE + (offset + i)*4);
    }
    return length;
}

u32 XHash_Write_result_Bytes(XHash *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XHASH_CONTROL_ADDR_RESULT_HIGH - XHASH_CONTROL_ADDR_RESULT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XHASH_CONTROL_ADDR_RESULT_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XHash_Read_result_Bytes(XHash *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XHASH_CONTROL_ADDR_RESULT_HIGH - XHASH_CONTROL_ADDR_RESULT_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XHASH_CONTROL_ADDR_RESULT_BASE + offset + i);
    }
    return length;
}

void XHash_InterruptGlobalEnable(XHash *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_GIE, 1);
}

void XHash_InterruptGlobalDisable(XHash *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_GIE, 0);
}

void XHash_InterruptEnable(XHash *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_IER);
    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_IER, Register | Mask);
}

void XHash_InterruptDisable(XHash *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_IER);
    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_IER, Register & (~Mask));
}

void XHash_InterruptClear(XHash *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHash_WriteReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_ISR, Mask);
}

u32 XHash_InterruptGetEnabled(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_IER);
}

u32 XHash_InterruptGetStatus(XHash *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHash_ReadReg(InstancePtr->Control_BaseAddress, XHASH_CONTROL_ADDR_ISR);
}

