// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of text_length
//        bit 31~0 - text_length[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of text_input
//        bit 31~0 - text_input[31:0] (Read/Write)
// 0x24 : Data signal of text_input
//        bit 31~0 - text_input[63:32] (Read/Write)
// 0x28 : reserved
// 0x40 ~
// 0x5f : Memory 'result' (32 * 8b)
//        Word n : bit [ 7: 0] - result[4n]
//                 bit [15: 8] - result[4n+1]
//                 bit [23:16] - result[4n+2]
//                 bit [31:24] - result[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XHASH_CONTROL_ADDR_AP_CTRL          0x00
#define XHASH_CONTROL_ADDR_GIE              0x04
#define XHASH_CONTROL_ADDR_IER              0x08
#define XHASH_CONTROL_ADDR_ISR              0x0c
#define XHASH_CONTROL_ADDR_AP_RETURN        0x10
#define XHASH_CONTROL_BITS_AP_RETURN        32
#define XHASH_CONTROL_ADDR_TEXT_LENGTH_DATA 0x18
#define XHASH_CONTROL_BITS_TEXT_LENGTH_DATA 32
#define XHASH_CONTROL_ADDR_TEXT_INPUT_DATA  0x20
#define XHASH_CONTROL_BITS_TEXT_INPUT_DATA  64
#define XHASH_CONTROL_ADDR_RESULT_BASE      0x40
#define XHASH_CONTROL_ADDR_RESULT_HIGH      0x5f
#define XHASH_CONTROL_WIDTH_RESULT          8
#define XHASH_CONTROL_DEPTH_RESULT          32

